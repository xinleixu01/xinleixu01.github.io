const foodTypes = ["所有", "快餐", "小吃", "中餐", "西餐", "日料", "韩料", "东南亚菜", "火锅", "烧烤", "自助餐", "甜点", "咖啡", "奶茶"];

window.onload = function() {
    const typeContainer = document.getElementById('typeContainer');
    let checkboxesHTML = '';
    foodTypes.forEach(type => {
        checkboxesHTML += `<label><input type="checkbox" name="foodType" value="${type}" onchange="handleFoodTypeChange(this)"> ${type}</label>`
    });
    typeContainer.innerHTML = checkboxesHTML;
};

function handleFoodTypeChange(checkbox) {
    if (checkbox.value === "所有" && checkbox.checked) {
        const checkboxes = document.getElementsByName("foodType");
        checkboxes.forEach(cb => {
            if (cb.value !== "所有") {
                cb.checked = false;
            }
        });
    } else if (checkbox.value !== "所有" && checkbox.checked) {
        document.querySelector('input[value="所有"]').checked = false;
    }
}

function toggleCustomRadius(select) {
    const customRadiusInput = document.getElementById('customRadiusInput');
    if (select.value === 'custom') {
        customRadiusInput.style.display = 'inline-block';
    } else {
        customRadiusInput.style.display = 'none';
    }
}
const key = "f658f0c4704a9904ab291a63d2af50b4";




// 搜索参数
// const radius = 500;
const offset = 20;

let currentLng = null;
let currentLat = null;


// =============================
// 页面加载 → 自动定位
// =============================




// =============================
// 自动补全地址
// =============================

function autoComplete() {

    const keyword = document.getElementById("addressInput").value;

    if (keyword.length < 2) {
        document.getElementById("tips").innerHTML = "";
        return;
    }

    const url =
        `https://restapi.amap.com/v3/assistant/inputtips?key=${key}&keywords=${keyword}&citylimit=true`;

    fetch(url)
        .then(res => res.json())
        .then(data => {

            let html = "";

            data.tips.forEach(t => {

                if (!t.location) return;

                html += `
                <div class="tipItem"
                onclick="chooseLocation('${t.location}', '${t.name}')">

                <b>${t.name}</b><br>
                ${t.district || ""}

                </div>
                `;

            });

            document.getElementById("tips").innerHTML = html;

        });

}


// =============================
// 选择地址
// =============================

function chooseLocation(loc, name) {

    document.getElementById("tips").innerHTML = "";
    document.getElementById("addressInput").value = name;

    const [lng, lat] = loc.split(",");

    currentLng = lng;
    currentLat = lat;

}


// =============================
// 定位按钮
// =============================

function locateMe() {

    if (!navigator.geolocation) {
        alert("浏览器不支持定位");
        return;
    }

    navigator.geolocation.getCurrentPosition(position => {

        currentLng = position.coords.longitude;
        currentLat = position.coords.latitude;

        document.getElementById("addressInput").value = "[我的位置]";

    });

}

// =============================
// 开始搜索
// =============================
function startSearch() {
    if(!currentLng || !currentLat) {
        alert("请先输入地址或定位");
        return;
    }

    let radius = document.getElementById("radiusSelect").value;
    if (radius === 'custom') {
        radius = document.getElementById('customRadiusInput').value;
        if (!radius || radius <= 0) {
            alert("请输入有效的自定义距离！");
            return;
        }
    }

    const selectedTypes = [];
    const checkboxes = document.getElementsByName("foodType");
    checkboxes.forEach(cb => {
        if (cb.checked) {
            selectedTypes.push(cb.value);
        }
    });
    
    let type = selectedTypes.join('|');
    if (type.includes("所有") || type === "") {
        type = "美食"; // Use a general category if "所有" is selected or nothing is selected
    }


    searchNearbyRestaurants(currentLng, currentLat, radius, type);
}


// =============================
// 搜索附近餐厅
// =============================

function searchNearbyRestaurants(lng, lat, radius, type) {

    document.getElementById("result").innerHTML = "正在搜索附近餐厅...";

    const url =
        `https://restapi.amap.com/v3/place/around?key=${key}&location=${lng},${lat}&keywords=${type}&radius=${radius}&offset=${offset}&page=1&extensions=all`;

    fetch(url)
        .then(res => res.json())
        .then(data => {

            const pois = data.pois || [];

            if (!pois.length) {

                document.getElementById("result").innerText =
                    "附近没有找到餐厅";

                return;

            }

            renderRestaurants(pois);

        })
        .catch(() => {

            document.getElementById("result").innerText =
                "搜索失败，请检查 Key 或网络";

        });

}


// =============================
// 渲染餐厅列表
// =============================

function renderRestaurants(pois) {

    let html = "";

    pois.forEach(p => {

        html += `
        <div class="card">

            <div class="name">${p.name}</div>

            <div>地址: ${p.address || "未知"}</div>

            <div>类型: ${p.type || "未知"}</div>

            <div>距离: ${p.distance || "未知"} 米</div>

        </div>
        `;

    });

    document.getElementById("result").innerHTML = html;

}

// =============================
// 随机选一家
// =============================

function randomPick() {

    const restaurantCards = document.querySelectorAll("#result .card");

    if (restaurantCards.length === 0) {
        alert("请先搜索餐厅列表");
        return;
    }

    const randomIndex = Math.floor(Math.random() * restaurantCards.length);
    const randomRestaurant = restaurantCards[randomIndex];

    const restaurantName = randomRestaurant.querySelector(".name").innerText;

    alert(`今天就吃：${restaurantName}`);

}

// =============================
// AI 决策助手
// =============================
async function getAIAdvice() {
    const restaurantCards = document.querySelectorAll("#result .card");

    if (restaurantCards.length === 0) {
        alert("请先搜索餐厅列表，AI才能给你建议");
        return;
    }

    let restaurantList = [];
    restaurantCards.forEach(card => {
        restaurantList.push(card.querySelector('.name').innerText);
    });

    const prompt = `我不知道该吃什么，这里是附近的餐厅列表：[${restaurantList.join(', ')}]。请根据这些选项，给我一些建议，并最终推荐一家。请以JSON格式返回，格式为：[{"name": "餐厅名", "reason": "推荐理由"}]`;

    const adviceContainer = document.getElementById("ai-advice");
    adviceContainer.innerHTML = "🤖 AI正在思考中...";

    try {
        const response = await callDeepSeekAPI(prompt);
        renderAIResponse(response);
    } catch (error) {
        adviceContainer.innerHTML = "调用 AI 服务失败，请检查你的 API Key 或网络连接。";
        console.error(error);
    }
}


async function getAIRecommendations(isRefresh = false) {
    const restaurantCards = document.querySelectorAll("#result .card");

    if (restaurantCards.length === 0) {
        alert("请先搜索餐厅列表，AI才能给你建议");
        return;
    }

    let restaurantList = [];
    restaurantCards.forEach(card => {
        restaurantList.push(card.querySelector('.name').innerText);
    });

    const userInput = document.getElementById('ai-prompt-input').value;

    if (!userInput) {
        alert("请输入你的美食偏好，比如 '我想吃辣一点的、距离近一点的'");
        return;
    }

    let prompt = `我不知道该吃什么，我的偏好是：'${userInput}'。\
这里是附近的餐厅列表：[${restaurantList.join(', ')}]。\
请根据我的偏好，从列表中推荐3家最符合要求的餐厅。请以JSON格式返回，格式为：[{"name": "餐厅名", "reason": "推荐理由"}]`;

    if (isRefresh) {
        prompt += "\n请给我换一批不同的推荐。"
    }

    const adviceContainer = document.getElementById("ai-advice");
    adviceContainer.innerHTML = "🤖 AI正在思考中...";

    try {
        const response = await callDeepSeekAPI(prompt);
        renderAIResponse(response);
    } catch (error) {
        adviceContainer.innerHTML = "调用 AI 服务失败，请检查你的 API Key 或网络连接。";
        console.error(error);
    }
}

function renderAIResponse(response) {
    const adviceContainer = document.getElementById("ai-advice");
    try {
        // Sanitize and parse the JSON response
        const sanitizedResponse = response.replace(/```json/g, '').replace(/```/g, '');
        const recommendations = JSON.parse(sanitizedResponse);

        if (!Array.isArray(recommendations) || recommendations.length === 0) {
            adviceContainer.innerHTML = "AI没有给出有效的推荐，请再试一次。";
            return;
        }

        let html = "";
        recommendations.forEach(rec => {
            html += `
            <div class="card ai-recommendation">
                <div class="name">${rec.name}</div>
                <div class="reason"><b>推荐理由:</b> ${rec.reason}</div>
            </div>
            `;
        });
        adviceContainer.innerHTML = html;
    } catch (e) {
        console.error("解析AI响应失败:", e, "原始响应:", response);
        // If parsing fails, display the raw text as a fallback.
        adviceContainer.innerHTML = response;
    }
}

// =============================
// 调用 DeepSeek API
// =============================
async function callDeepSeekAPI(prompt) {

    // 调用我们自己的后端代理服务
    const response = await fetch("http://127.0.0.1:5001/get-ai-advice", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: prompt })
    });

    if (!response.ok) {
        const err = await response.json();
        console.error(err);
        throw new Error("API 请求失败");
    }

    const data = await response.json();
    //return data.choices[0].message.content;
    return data.reply;
}
